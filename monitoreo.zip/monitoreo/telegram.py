import requests
import sys
import base64
import os
from secrets import choice 
import mysql.connector

caracteres = '/()@=abcdefghijklmnopqrstuvwxyz1234567890'
longitud = 12 

CHAT_ID = '@torkeenks'
BOT_TOKEN = '1162523443:AAFHsZZml5mlobenoCKTRcbIShHmxYES23Y'

def tokenAleatorio():
	token = ''.join(choice(caracteres) for caracter in range(longitud))
	print("la cadena es: ", token)
	return token

def mandar_mensaje(mensaje):
	send_text = 'https://api.telegram.org/bot%s/sendMessage?chat_id=%s&parse_mode=Markdown&text=%s' % (BOT_TOKEN, CHAT_ID, token)
	response = requests.get(send_text)
	return response.json()

def actualizaToken(token):
	mydb = mysql.connector.connect(host="localhost",user="luna",passwd="12345",database="monitoreo")
	mycursor = mydb.cursor()
	sql = "UPDATE monitoreoApp_adminglobal SET token= %s WHERE ID= %s"
	val= (token,'1')
	mycursor.execute(sql,val)
	mydb.commit()

if __name__ == '__main__':
	#mensaje = sys.argv[1]
	token = tokenAleatorio()
	respuesta = mandar_mensaje(token)
	actualizaToken(token)
	print(respuesta)
