from subprocess import Popen

from django.shortcuts import render, redirect

import base64
import os
import crypt

import monitoreo.validaIp as validaIp
from monitoreoApp import models


def login(request):
    t = 'login.html'
    if request.method == 'GET':
        return render(request, t)
    elif request.method == 'POST':
        if validaIp.dejar_pasar_peticion_login(request):
            usuario = request.POST.get('usuario').strip()
            password = request.POST.get('password').strip()
            datosUsuario = models.adminGlobal.objects.all()
            for datos in datosUsuario:
                if datos.usuario == usuario:
                    passwordBase = datos.password#hash en la base
                    partes = passwordBase.split('$')
                    header = '$' + partes[1] + '$' + partes[2]
                    passwordTemplate = crypt.crypt(password, header)
                    print("template", passwordTemplate, "base:", passwordBase)
                    if passwordBase == passwordTemplate:
                        request.session['logueado'] = True
                        process = Popen(['python3', 'telegram.py'])
                        return redirect('/token/')
                    else:
                        return render(request, t, {'errores': 'Error en el credeciales'})
        else:
            return render(request, t, {'errores': 'Numero de intentos excedido espera un minuto'})
    return render(request, t)


def listaEditoriales(request):

    pass
    #editoriales = models.Editorial.objects.all().order_by('nombre')
    #t = 'biblioteca/listaEditoriales.html'
    #c = {'editoriales': editoriales}
    #for editorial in editoriales:
    #    editorial.nombre, editorial.ciudad

    #return render(request, t, c)


def token(request):
    t = 'token.html'
    t2 = 'login.html'
    if request.method == 'GET':
        return render(request, t)
    elif request.method == 'POST':
        token = request.POST.get('token').strip()
        try:
            models.adminGlobal.objects.get(token=token)
            request.session['logueado'] = True

            return redirect('/funcionesAdministrador/')
        except:
            process = Popen(['python3', 'borrar.py'])
            request.session['logueado'] = False
            return render(request, t2, {'errores':'Error en el token'})


def funcionesAdministrador(request):
    t='funcionesAdministrador.html'
    return render(request, t)


def cifrar(password):
    print(password)
    salt = base64.b64encode(os.urandom(10)).decode('utf-8')
    hasheado = crypt.crypt(password, '$6$' + salt)
    return hasheado


def logout(request):
    request.session['logueado'] = False
    return redirect('/login/')
