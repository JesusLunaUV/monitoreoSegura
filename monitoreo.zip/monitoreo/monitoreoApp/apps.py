from django.apps import AppConfig


class MonitoreoappConfig(AppConfig):
    name = 'monitoreoApp'
