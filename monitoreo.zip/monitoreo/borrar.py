import mysql.connector
token=''
mydb = mysql.connector.connect(
  host="localhost",
  user="luna",
  passwd="12345",
  database="monitoreo"
)

mycursor = mydb.cursor()

sql = "UPDATE monitoreoApp_adminglobal SET token= %s WHERE ID= %s"
val = (token,'1')

mycursor.execute(sql, val)

mydb.commit()

print(mycursor.rowcount, "record(s) affected") 
